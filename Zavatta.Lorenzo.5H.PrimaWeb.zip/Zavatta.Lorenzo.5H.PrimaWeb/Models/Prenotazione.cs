using System;
using System.ComponentModel.DataAnnotations;

namespace Zavatta.Lorenzo._5H.PrimaWeb.Models
{
    public class Prenotazione
    {
        public int Prenotazioneid {get;set;}
        public string Nome { get; set; }

        [Required(ErrorMessage="Inserisci un Email valdia")]
        [EmailAddress]
        public string Email { get;set;} 
    }
}