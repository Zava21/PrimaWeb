﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Zavatta.Lorenzo._5H.PrimaWeb.Models;

namespace Zavatta.Lorenzo._5H.PrimaWeb.Controllers
{
    public class HomeController : Controller
    {
        static List<Prenotazione> prenotazioni = new List<Prenotazione>();

        public IActionResult Index()
        {
            /*var db = new PrenotazioneContext();
            {
                // Create
                Console.WriteLine("Inserting a new blog");
                db.Prenotazioni.Add(new Prenotazione { Nome = "Lorenzo", Email="lorenzo@gmail.com" });
                db.SaveChanges();
                return View();
            }*/

            return View();
        }

        [HttpGet]
        public IActionResult Prenota()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Prenota(Prenotazione p)
        {
            var db = new  PrenotazioneContext();
            db.Prenotazioni.Add(p);
            db.SaveChanges();

            return View("Grazie" , db); //Chiamo index e passi p
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Cancella()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
