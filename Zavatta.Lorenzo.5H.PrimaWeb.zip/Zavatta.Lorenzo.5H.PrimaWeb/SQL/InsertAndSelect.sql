-- SQLite
INSERT INTO Prenotazioni( Nome, Email )
VALUES("Pino","Pino@insegno.it");

SELECT Prenotazioneid, Nome, Email
FROM Prenotazioni;