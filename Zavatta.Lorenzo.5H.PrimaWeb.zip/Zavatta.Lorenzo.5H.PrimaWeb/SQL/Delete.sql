DELETE 
FROM Prenotazioni
WHERE Prenotazioneid=14 OR Prenotazioneid=13;

SELECT * 
FROM Prenotazioni;